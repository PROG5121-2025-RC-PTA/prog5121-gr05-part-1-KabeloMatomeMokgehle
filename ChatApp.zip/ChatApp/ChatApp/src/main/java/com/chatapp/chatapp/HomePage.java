/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.chatapp.chatapp;


import javax.swing.*;
import java.awt.event.*;

public class HomePage {
    private String username;
    private String firstname;
    private String lastname;
    public HomePage(String firstname, String lastname) {
        this.firstname = username;
        this.lastname = lastname;

        JOptionPane.showMessageDialog(null, "Welcome " +firstname+" "+ " "+lastname + "!");
    }

}
        
    

